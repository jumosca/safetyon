SAFETYON-REGULAR
A display typeface by Julie Moscatelli.

Inspired by the diagrams on Ryanair safety cards — specifically, the
figure of a woman crossing her arms while sliding down an emergency
chute, body forming a perfect 'X'.

This typeface is an independent design and is not affiliated with,
endorsed by, or licensed by Ryanair Holdings plc.

-----------------------------------------------------------
Format:   TrueType (.ttf)
Weight:   Regular (400)
Year:     2026
Licence:  SIL Open Font License 1.1 (see OFL.txt)
-----------------------------------------------------------

Designer: Julie Moscatelli
Email:    julie.moscatelli@gmail.com
